package com.pratik.bookapp.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.pratik.bookapp.R
import com.pratik.bookapp.activity.DescriptionActivity
import com.pratik.bookapp.model.Book
import com.squareup.picasso.Picasso

class DashboardRecyclerAdapter(val context: Context,val itemList:ArrayList<Book>) : RecyclerView.Adapter<DashboardRecyclerAdapter.DashboardViewHolder>() {
    class DashboardViewHolder(view:View): RecyclerView.ViewHolder(view)
    {
        val txtbookname:TextView=view.findViewById(R.id.txtbookname)
        val txtnameofauthor:TextView=view.findViewById(R.id.txtnameofauthor)
        val txtprice:TextView=view.findViewById(R.id.txtprice)
        val txtrating:TextView=view.findViewById(R.id.txtrating)
        val imganne:ImageView=view.findViewById(R.id.imganne)
        val rlcontent:RelativeLayout=view.findViewById(R.id.rlcontent)


    }



    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
        val book=itemList[position]
        holder.txtbookname.text=book.bookname
        holder.txtnameofauthor.text=book.booknameofauthor
        holder.txtprice.text=book.bookprice
        holder.txtrating.text=book.bookrating
        Picasso.get().load(book.bookimage).error(R.drawable.default_book_cover).into(holder.imganne)
//        holder.imganne.setImageResource(book.bookimage)
        holder.rlcontent.setOnClickListener {
            Toast.makeText(context,"Clicked on  ${holder.txtbookname.text}",Toast.LENGTH_SHORT).show()

//            val intent=Intent(context,DescriptionActivity::class.java)
//            intent.putExtra("book_id",book.bookId)
//            context.startActivity(intent)
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_dashboard_single_row,parent,false)
        return DashboardViewHolder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }


}
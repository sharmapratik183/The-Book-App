package com.pratik.bookapp.model

data class Book (
    val bookId:String,
    val bookname: String ,
    val booknameofauthor: String ,
    val bookrating: String,
    val bookprice: String,
    val bookimage: String
    )
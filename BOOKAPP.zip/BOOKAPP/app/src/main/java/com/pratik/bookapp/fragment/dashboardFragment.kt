package com.pratik.bookapp.fragment

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.pratik.bookapp.R
import com.pratik.bookapp.adapter.DashboardRecyclerAdapter
import com.pratik.bookapp.model.Book
import com.pratik.bookapp.util.ConnectionManager
import org.json.JSONException
import java.lang.Error


private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


class dashboardFragment : Fragment() {
    lateinit var recyclerdashboard : RecyclerView
    lateinit var layoutManager: RecyclerView.LayoutManager
    lateinit var recyclerAdapter: DashboardRecyclerAdapter

    lateinit var progressLayout:RelativeLayout
    lateinit var progressBar:ProgressBar
    val bookinfolist= arrayListOf<Book>()
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view= inflater.inflate(R.layout.fragment_dashboard, container, false)
        recyclerdashboard = view.findViewById(R.id.recyclerdashboard)

        progressBar=view.findViewById(R.id.progressBar)
        progressLayout=view.findViewById(R.id.progressLayout)
        progressLayout.visibility=View.VISIBLE

        layoutManager=LinearLayoutManager(activity)

        val queue=Volley.newRequestQueue(activity as Context)
        val url="http://13.235.250.119/v1/book/fetch_books/"
        if(ConnectionManager() checkConnectivity(activity as Context))
        {
            val jsonObjectRequest = object : JsonObjectRequest(Request.Method.GET,url,null, Response.Listener {

                try{
                    progressLayout.visibility=View.GONE
                    val success = it.getBoolean("success")
                    if(success)
                    {
                        val data=it.getJSONArray("data")
                        for(i in 0 until data.length())
                        {
                            val bookJsonObject=data.getJSONObject(i)
                            val bookObject=Book(
                                bookJsonObject.getString("book_id"),
                                bookJsonObject.getString("name"),
                                bookJsonObject.getString("author"),
                                bookJsonObject.getString("rating"),
                                bookJsonObject.getString("price"),
                                bookJsonObject.getString("image")
                            )
                            bookinfolist.add(bookObject)
                            recyclerAdapter= DashboardRecyclerAdapter(activity as Context,bookinfolist)
                            recyclerdashboard.adapter=recyclerAdapter
                            recyclerdashboard.layoutManager=layoutManager
                        }
                    }
                    else
                    {
                        Toast.makeText(activity as Context,"Some Error Occured",Toast.LENGTH_SHORT).show()
                    }

                }
                catch (e:JSONException)
                {
                    Toast.makeText(activity as Context,"Some Unexpected Error Occured!!!",Toast.LENGTH_SHORT).show()
                }


            },Response.ErrorListener {
                Toast.makeText(activity as Context,"Volley Error Occured!!!",Toast.LENGTH_SHORT).show()
            })
            {
                override fun getHeaders(): MutableMap<String, String> {
                    val headers=HashMap<String,String>()
                    headers["Content-type"] = "application/Json"
                    headers["token"] = "630d2a870723d7"
                    return headers
                }

            }
            queue.add(jsonObjectRequest)


        }
        else
        {
            val dialog=AlertDialog.Builder(activity as Context)
            dialog.setTitle("Error")
            dialog.setMessage("Internet Connection not Found")
            dialog.setPositiveButton("Open Settings") { text, listener ->
                val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                startActivity(settingsIntent)
                activity?.finish()
            }
            dialog.setNegativeButton("Exit") { text, listener->
                ActivityCompat.finishAffinity(activity as Activity)

            }
            dialog.create()
            dialog.show()

        }

        // Inflate the layout for this fragment

        return view
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment dashboardFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            dashboardFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}
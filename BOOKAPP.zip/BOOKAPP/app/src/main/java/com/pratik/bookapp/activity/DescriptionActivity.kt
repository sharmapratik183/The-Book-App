package com.pratik.bookapp.activity

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.pratik.bookapp.R
import com.pratik.bookapp.adapter.DashboardRecyclerAdapter
import com.pratik.bookapp.model.Book
import com.squareup.picasso.Picasso
import org.json.JSONException
import org.json.JSONObject

class DescriptionActivity : AppCompatActivity() {

    lateinit var txtbookname2:TextView
    lateinit var txtbookauthor:TextView
    lateinit var txtbookrating:TextView
    lateinit var txtbookprice:TextView
    lateinit var progressBar2: ProgressBar
    lateinit var progresslayout2:RelativeLayout
    lateinit var btnaddtofav:Button
    lateinit var txtdescription:TextView
    lateinit var imgbookimage:ImageView

    var bookId : String? ="100"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)
        txtbookname2=findViewById(R.id.txtbookname2)
        txtbookauthor=findViewById(R.id.txtbookauthor)
        txtbookrating=findViewById(R.id.txtbookrating)
        txtbookprice=findViewById(R.id.txtbookprice)
        progressBar2=findViewById(R.id.progressBar2)
        progressBar2.visibility=View.VISIBLE
        progresslayout2=findViewById(R.id.progresslayout2)
        btnaddtofav=findViewById(R.id.btnaddtofav)
        txtdescription=findViewById(R.id.txtdescription)
        imgbookimage=findViewById(R.id.imgbookimage)
        progresslayout2.visibility=View.VISIBLE

        if(intent != null)
        {
            bookId= intent.getStringExtra("book_id")
        }
        else
        {
            finish()
            Toast.makeText(this@DescriptionActivity,"Some Error Occured",Toast.LENGTH_SHORT).show()

        }
        if(bookId=="100")
        {
            finish()
            Toast.makeText(this@DescriptionActivity,"Some Error Occured!!",Toast.LENGTH_SHORT).show()
        }

        val queue= Volley.newRequestQueue(this@DescriptionActivity)
        val url="http://13.235.250.119/v1/book/get_book/"

        val jsonParams = JSONObject()
        jsonParams.put("book_id",bookId)

        val jsonRequest = object : JsonObjectRequest(Request.Method.POST,url,jsonParams, Response.Listener {
            try{

                val success = it.getBoolean("success")
                if(success)
                {
                    progresslayout2.visibility=View.GONE
                    val bookJsonObject=it.getJSONObject("book_data")


                    Picasso.get().load(bookJsonObject.getString("image"))


                           txtbookname2.text= bookJsonObject.getString("name")
                            txtbookauthor.text=bookJsonObject.getString("author")
                           txtbookprice.text= bookJsonObject.getString("price")
                            txtbookrating.text=bookJsonObject.getString("rating")
                            txtdescription.text=bookJsonObject.getString("description")


                    }

                else
                {
                    Toast.makeText(this@DescriptionActivity,"Some Error Occured",Toast.LENGTH_SHORT).show()
                }

            }
            catch (e: Exception)
            {
                Toast.makeText(this@DescriptionActivity,"Some Unexpected Error Occured!!!",Toast.LENGTH_SHORT).show()
            }

        },Response.ErrorListener {
            Toast.makeText(this@DescriptionActivity,"Volley Error $it",Toast.LENGTH_SHORT).show()

        }){
            override fun getHeaders(): MutableMap<String, String> {
                val headers=HashMap<String,String>()
                headers["Content-type"] = "application/json"
                headers["token"] = "630d2a870723d7"
                return headers
            }

        }
    }
}